// in Ex2 to Ex5, change the name of the following function properly
function volume() {

  var a=document.getElementById("number1").value;
  var b=document.getElementById("number2").value;
  var c=document.getElementById("number3").value;

  /* in Ex2 to Ex4, you need to replace the following line
      with some other formulas */
  var p = 4/3 * Math.PI * Math.pow(a, b, c);
  var s = parseFloat(4*Math.sqrt(p*(p-a)*(p-b)*(p-c)));
  var v = s.toFixed(2);

  /* in Ex5, you should delete from Line 9 to this line */

  /*   //in Ex 5, uncomment this block
  switch (true){
	case (a>89):
		answer="A+";
		break;
	case (a>79):
		answer="A";
		break;
		// in Ex5, you need to add more cases for other letter grades
	default:
		answer="F";
  }
  */

  /* in Ex2 to Ex5, you need to rename "perimeter" to make it appropriate
     for those problems, you may also need to rename p to a better
	 variable that you might have in your formulas above */
  document.getElementById("output").innerHTML="volume: "+v;

}
