function mapping(){
    var a = parseInt(document.getElementById("num1").value);
    switch (true){
        case (a>89): 
        document.getElementById("output").innerHTML = "A+";;
           break;
        case (a>79): 
        document.getElementById("output").innerHTML = "A";;
           break;
           case(a>74):
           document.getElementById("output").innerHTML = "B+";
           break;
           case(a>69):
           document.getElementById("output").innerHTML = "B";
           break;
           case(a>64):
           document.getElementById("output").innerHTML = "C+";
           break;
           case(a>59):
           document.getElementById("output").innerHTML = "C";
           break;
           case(a>54):
           document.getElementById("output").innerHTML = "D+";
           break;
           case(a>49):
           document.getElementById("output").innerHTML = "D";
           break;
           case(a>39):
           document.getElementById("output").innerHTML = "E";
           break;
            

           // in Ex5, you need to add more cases for other letter grades
        default:
         document.getElementById("output").innerHTML = "F";
       }
}