function problem_09() {

  var outputObj=document.getElementById("output");


  var a = parseInt(prompt("Please enter a number: ", ""));
  var num = 0;


  outputObj.innerHTML="number: "+a+"<br><br>its digits: ";


while (a > 0){
    num = (a % 10);
    outputObj.innerHTML+=num+", ";
    a = Math.floor(a / 10);

}

  outputObj.innerHTML=outputObj.innerHTML+"<br><br>"+"program ended";
  document.getElementsByTagName("button")[0].setAttribute("disabled","true");
}
