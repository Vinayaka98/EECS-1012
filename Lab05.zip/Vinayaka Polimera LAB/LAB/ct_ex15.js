function problem_15() {

    document.getElementById("output").style.textAlign = "left";
    document.getElementById("output").style.fontSize ="11px";
    var outputObj = document.getElementById("output");


    var a = parseInt(prompt("Please enter a number: ", ""));
    outputObj.innerHTML = "number: " + a + "<br><br>its digits: <br>";

    for (let i = 0; i < a; i++) {
    for (let j = 0; j <= i; j++) {
    outputObj.innerHTML += "XX ";
    }
    outputObj.innerHTML += "<br>";
    }

    outputObj.innerHTML = outputObj.innerHTML + "<br><br>" + "program ended";
    document.getElementsByTagName("button")[0].setAttribute("disabled", "true");
    }
