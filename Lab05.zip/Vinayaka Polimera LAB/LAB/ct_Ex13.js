function factorial() {

  var outputObj=document.getElementById("output");

  var a = parseInt(prompt("Please enter a number: ", ""));
  var num = a;
  var fact=1;

  for (var i=2;i<=num;i++)
  {
    fact = fact * i;
  }

  outputObj.innerHTML="number: "+a+"<br><br>"+a+"!="+fact;

  outputObj.innerHTML=outputObj.innerHTML+"<br><br>"+"program ended";
  document.getElementsByTagName("button")[0].setAttribute("disabled","true");
}
