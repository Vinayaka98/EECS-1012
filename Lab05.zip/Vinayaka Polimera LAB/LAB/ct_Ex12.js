function problem_12() {


  var outputObj=document.getElementById("output");


  var a = parseInt(prompt("Please enter a number: ", ""));
  var temp = a;
  var reverse  = 0;

  while (a > 0)
  {
    var d = a % 10;
    reverse = reverse * 10 + d;
    a = Math.floor(a/10);

  }

  var equal;
  if(temp==reverse)
  {
    equal = "yes";
  }
  else
  {
    equal = "no";
  }


  outputObj.innerHTML="number: "+temp+"<br><br>equal to its reverse? " +equal;


  outputObj.innerHTML=outputObj.innerHTML+"<br><br>"+"program ended";
  document.getElementsByTagName("button")[0].setAttribute("disabled","true");
}
