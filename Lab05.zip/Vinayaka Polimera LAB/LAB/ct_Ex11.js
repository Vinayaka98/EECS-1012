function problem_11() {


  var outputObj=document.getElementById("output");

  var a = parseInt(prompt("Please enter a number: ", ""));
  var sum = 0;
  var num  = a;

  while (num > 0)
  {
    var d = num % 10;
    sum += d;
    num = Math.floor(num/10);
  }

  outputObj.innerHTML="number: "+a+"<br><br>sum of digits: " +sum;


  outputObj.innerHTML=outputObj.innerHTML+"<br><br>"+"program ended";
  document.getElementsByTagName("button")[0].setAttribute("disabled","true");
}
