function fibonacci(n)
{

if (n <= 1)
return n;
return fibonacci(n - 1) + fibonacci(n - 2);
}

function problem_14() {

var outputObj = document.getElementById("output");
var a = parseInt(prompt("Please enter a number: ", ""));


outputObj.innerHTML = "number: " + a + "<br><br>Fibonacci: ";
var comma = "";
for (let i = 0; i <= a; i++) {
outputObj.innerHTML += comma + fibonacci(i);
comma = ", "
}

outputObj.innerHTML = outputObj.innerHTML + "<br><br>" + "program ended";
document.getElementsByTagName("button")[0].setAttribute("disabled", "true");
}
